'use strict';

module.exports = function (app) {
    var hitLbdoc = require('../controllers/hitLbdocController');

    app.route('/hitLbdoc/:elementId')
        .get(hitLbdoc.read_lbdoc);
};